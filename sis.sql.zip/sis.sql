-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 12, 2018 at 01:38 PM
-- Server version: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sis`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `middle_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `login_attempts` int(2) DEFAULT NULL,
  `joined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `email`, `first_name`, `middle_name`, `last_name`, `phone_number`, `role`, `last_login`, `login_attempts`, `joined`) VALUES
(1, 'arksnorman', '$2y$10$5MqVZBytWldYeP1VBmaW6.e4LwF6Lt.4JH9rdTd5tsOxpBaBNaw0G', 'admin@admin.com', 'Admin', 'Top', 'Level', '+256750000000', 'admin', '2017-12-11 17:53:29', NULL, '2017-09-13 21:46:58'),
(2, 'admin', '$2y$10$5MqVZBytWldYeP1VBmaW6.e4LwF6Lt.4JH9rdTd5tsOxpBaBNaw0G', 'admin@admin.com', 'admin', 'admin', 'admin', '+256781668437', 'admin', '2017-12-15 11:06:31', NULL, '2017-12-15 11:06:31');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `creator` varchar(255) NOT NULL,
  `date_added` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `title`, `message`, `creator`, `date_added`) VALUES
(1, 'Little time for lectures', 'We get less time for lecturers', 'arksnorman', '2017-11-13 02:33:04am'),
(2, 'Testing', 'Testing', 'arksnorman', '2017-11-13 02:46:36am'),
(3, 'Computers are very slow', 'I think computers need maintenance and updates', 'arksnorman', '2017-11-13 02:51:27pm'),
(4, 'hhhhhhhhhhhhhh', 'ffffffffffffffffff', 'arksnorman', '2017-11-13 03:34:18pm'),
(5, 'dfdsgsj', 'dfksdjgfdsjkdjfsd', 'tommy', '2017-12-13 03:26:04pm'),
(6, 'Test', 'hello', 'marshall', '2017-12-15 12:01:45pm'),
(7, 'Computers are not working well', 'fffffffffffddddddddddddddddddddd', 'marshall', '2017-12-15 04:32:03pm');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `years` int(1) NOT NULL,
  `date_added` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `name`, `department`, `years`, `date_added`) VALUES
(1, 'Information Technology', 'IT Department', 3, '12-1-2017'),
(2, 'Business Administration', 'Business Department', 2, '2017-12-01 08:38:55pm'),
(3, 'Journalism', 'Media', 2, '2017-12-14'),
(4, 'Software engineering', 'IT', 3, '2017-12-14');

-- --------------------------------------------------------

--
-- Table structure for table `lecturers`
--

CREATE TABLE `lecturers` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `middle_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `login_attempts` int(2) DEFAULT NULL,
  `joined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `department` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturers`
--

INSERT INTO `lecturers` (`id`, `username`, `password`, `email`, `first_name`, `middle_name`, `last_name`, `phone_number`, `last_login`, `login_attempts`, `joined`, `department`, `role`) VALUES
(1, 'marydoe', '$2y$10$5MqVZBytWldYeP1VBmaW6.e4LwF6Lt.4JH9rdTd5tsOxpBaBNaw0G', 'marydoe@doe.com', 'Mary', 'Jane', 'Doe', '+256750000000', '2017-12-11 10:39:58', 2, '2017-09-13 21:42:17', 'IT Dept', 'lecturer');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `added_by` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `year` int(5) NOT NULL,
  `semester` int(3) NOT NULL,
  `rootpath` varchar(255) NOT NULL,
  `webpath` varchar(255) NOT NULL,
  `date_added` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `description`, `added_by`, `course`, `year`, `semester`, `rootpath`, `webpath`, `date_added`) VALUES
(1, 'Introduction to computers', 'arksnorman', 'Computer Science', 1, 1, '/home/arksnorman/git/sis/web/../downloads/notes/5a0887e8c7f86-Sanyu2.odt', '/downloads/notes/5a0887e8c7f86-Sanyu2.odt', '2017-11-12 08:42:00pm'),
(2, 'Operating systems', 'arksnorman', 'Computer Science', 2, 2, '/home/arksnorman/git/sis/web/../downloads/notes/5a097ccc81d1d-Sanyu2.odt', '/downloads/notes/5a097ccc81d1d-Sanyu2.odt', '2017-11-13 02:06:52pm'),
(3, 'Test notes', 'arksnorman', 'Information Technology', 1, 1, '/home/arksnorman/git/sis/src/core/App/../../../downloads/notes/5a2fdfafb1a82-Dakirby309-Simply-Styled-OS-Ubuntu.ico', '/downloads/notes/5a2fdfafb1a82-Dakirby309-Simply-Styled-OS-Ubuntu.ico', '2017-12-12 04:54:55pm');

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` varchar(500) NOT NULL,
  `date_added` varchar(255) NOT NULL,
  `creator` varchar(255) NOT NULL,
  `date_updated` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `title`, `message`, `date_added`, `creator`, `date_updated`) VALUES
(1, 'Sales Representative', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy.', '2017-11-07', 'hspinnace0', NULL),
(2, 'Account Coordinator', 'Integer a nibh. svgfsdjjhfsjhfd', '2017-01-27', 'arksnorman', '2017-12-13 02:55:27am'),
(3, 'VP Marketing', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc.', '2017-06-20', 'acawcutt2', NULL),
(4, 'Compensation Analyst', 'Integer non velit. Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.', '2017-08-13', 'tfanton3', NULL),
(5, 'Assistant Professor', 'Nulla suscipit ligula in lacus.', '2017-09-11', 'mhiggan4', NULL),
(6, 'Programmer III', 'Aliquam erat volutpat. In congue.', '2017-10-07', 'jhearsum5', NULL),
(7, 'Research Nurse', 'In eleifend quam a odio. In hac habitasse platea dictumst.', '2017-04-17', 'dpierson6', NULL),
(8, 'Human Resources Assistant IV', 'Aenean lectus.', '2017-10-24', 'aquinnette7', NULL),
(9, 'Internal Auditor', 'Donec posuere metus vitae ipsum. Aliquam non mauris.', '2017-09-20', 'glusgdin8', NULL),
(10, 'Help Desk Operator', 'Morbi a ipsum. Integer a nibh.', '2017-12-08', 'akapelhof9', NULL),
(11, 'Operator', 'Aliquam non mauris.', '2017-01-14', 'dblasonia', NULL),
(12, 'Safety Technician II', 'Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante.', '2017-02-04', 'mdudgeonb', NULL),
(13, 'Computer Systems Analyst II', 'In eleifend quam a odio.', '2017-04-27', 'dhummc', NULL),
(14, 'Research Assistant IV', 'Quisque id justo sit amet sapien dignissim vestibulum.', '2017-06-20', 'amathetd', NULL),
(15, 'Sales Representative', 'Aenean auctor gravida sem. Praesent id massa id nisl venenatis lacinia.', '2017-01-22', 'gfiste', NULL),
(16, 'Developer I', 'Nulla facilisi. Cras non velit nec nisi vulputate nonummy.', '2017-09-15', 'cfussenf', NULL),
(17, 'Marketing Manager', 'Nullam varius. Nulla facilisi.', '2017-04-25', 'ckenwrickg', NULL),
(18, 'Director of Sales', 'Nulla mollis molestie lorem. Quisque ut erat.', '2017-07-06', 'keyesh', NULL),
(19, 'Administrative Officer', 'Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', '2017-10-22', 'emckeowoni', NULL),
(20, 'Software Test Engineer II', 'Vivamus vel nulla eget eros elementum pellentesque.', '2017-06-22', 'obranwhitej', NULL),
(21, 'Senior Quality Engineer', 'Vivamus tortor. Duis mattis egestas metus.', '2017-04-15', 'jeickhoffk', NULL),
(22, 'Junior Executive', 'Praesent lectus. Vestibulum quam sapien, varius ut, blandit non, interdum in, ante.', '2017-03-02', 'gmctrusteyl', NULL),
(23, 'Project Manager', 'Sed vel enim sit amet nunc viverra dapibus.', '2017-08-12', 'bwickershamm', NULL),
(24, 'Civil Engineer', 'In congue. Etiam justo.', '2017-11-12', 'hkhristyukhinn', NULL),
(25, 'VP Marketing', 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh. Quisque id justo sit amet sapien dignissim vestibulum.', '2017-01-03', 'bganleyo', NULL),
(26, 'Automation Specialist I', 'Phasellus sit amet erat.', '2017-02-17', 'fraynesp', NULL),
(27, 'Physical Therapy Assistant', 'Duis ac nibh.', '2017-12-02', 'mnottiq', NULL),
(28, 'Dental Hygienist', 'In congue. Etiam justo.', '2017-07-26', 'hwimmerr', NULL),
(29, 'Environmental Tech', 'Suspendisse potenti.', '2017-03-21', 'ladamidess', NULL),
(30, 'Nurse', 'In eleifend quam a odio. In hac habitasse platea dictumst.', '2017-12-05', 'bhymust', NULL),
(31, 'Help Desk Technician', 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst.', '2017-09-25', 'pvernyu', NULL),
(32, 'Geological Engineer', 'In eleifend quam a odio.', '2017-07-09', 'nsommervillev', NULL),
(33, 'Help Desk Technician', 'Morbi non quam nec dui luctus rutrum. Nulla tellus.', '2017-11-23', 'nlamsheadw', NULL),
(34, 'Automation Specialist I', 'Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', '2017-09-09', 'jstonnerx', NULL),
(35, 'Geological Engineer', 'Vivamus vel nulla eget eros elementum pellentesque. Quisque porta volutpat erat.', '2017-08-06', 'elathleiffurey', NULL),
(37, 'Statistician IV', 'Ut tellus.', '2017-06-25', 'pmilne10', NULL),
(38, 'Biostatistician IV', 'Integer a nibh.', '2017-07-05', 'jcorrigan11', NULL),
(39, 'Nurse Practicioner', 'Suspendisse potenti. Cras in purus eu magna vulputate luctus.', '2017-03-20', 'wrump12', NULL),
(40, 'Data Coordiator', 'Sed vel enim sit amet nunc viverra dapibus.', '2017-03-26', 'fconnal13', NULL),
(41, 'Senior Financial Analyst', 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.', '2017-05-28', 'mnoraway14', NULL),
(42, 'Registered Nurse', 'Nulla tempus.', '2017-10-18', 'klapsley15', NULL),
(43, 'Help Desk Operator', 'Phasellus sit amet erat. Nulla tempus.', '2017-10-08', 'bdilley16', NULL),
(44, 'Tax Accountant', 'Cras in purus eu magna vulputate luctus.', '2017-08-01', 'grattry17', NULL),
(45, 'Automation Specialist I', 'Nulla mollis molestie lorem. Quisque ut erat.', '2017-03-14', 'bfarnie18', NULL),
(46, 'Tax Accountant', 'Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', '2017-01-24', 'ocowey19', NULL),
(47, 'Senior Sales Associate', 'Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla.', '2017-05-06', 'mgoldberg1a', NULL),
(48, 'Media Manager I', 'Morbi non quam nec dui luctus rutrum.', '2017-11-18', 'rcarnew1b', NULL),
(49, 'Occupational Therapist', 'Ut at dolor quis odio consequat varius.', '2017-01-13', 'doutram1c', NULL),
(50, 'Chief Design Engineer', 'Integer ac neque. Duis bibendum.', '2017-04-01', 'kodooley1d', NULL),
(51, 'Mid exams coming soon', 'Get ready for mid exams', '2017-12-12 11:29:03pm', 'arksnorman', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `gender` varchar(15) DEFAULT NULL,
  `nationality` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `joined` varchar(255) DEFAULT NULL,
  `last_login` varchar(255) DEFAULT NULL,
  `login_attempts` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `username`, `email`, `course`, `gender`, `nationality`, `first_name`, `last_name`, `middle_name`, `password`, `joined`, `last_login`, `login_attempts`, `role`) VALUES
(1, 'marshall', 'marshal@example.edu', 'Information Technology', 'Male', 'Ugandan', 'tobby', 'marshal', 'marshal', '$2y$10$5MqVZBytWldYeP1VBmaW6.e4LwF6Lt.4JH9rdTd5tsOxpBaBNaw0G', '2017-12-15', NULL, NULL, 'student'),
(2, 'teststudent', 'ghddgf@gmail.com', 'Information Technology', 'Male', 'Ugandan', 'hhhhhhh', 'kkkkkkk', 'hhhhhhhh', '$2y$10$5MqVZBytWldYeP1VBmaW6.e4LwF6Lt.4JH9rdTd5tsOxpBaBNaw0G', '2017-12-15', NULL, NULL, 'student');

-- --------------------------------------------------------

--
-- Table structure for table `timetables`
--

CREATE TABLE `timetables` (
  `id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `added_by` varchar(255) NOT NULL,
  `rootpath` varchar(255) NOT NULL,
  `webpath` varchar(255) NOT NULL,
  `date_added` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetables`
--

INSERT INTO `timetables` (`id`, `description`, `added_by`, `rootpath`, `webpath`, `date_added`) VALUES
(1, 'End of Semester 2 exams 2017', 'arksnorman', '/home/arksnorman/git/sis/web/../downloads/timetables/5a0887a1a384a-toggle-oct-2017.png', '/downloads/timetables/5a0887a1a384a-toggle-oct-2017.png', '2017-11-12 08:40:49pm'),
(2, 'hjfjf', 'arksnorman', '/home/arksnorman/git/sis/web/../downloads/timetables/5a09952125c59-receipt.pdf', '/downloads/timetables/5a09952125c59-receipt.pdf', '2017-11-13 03:50:41pm'),
(3, 'ggg', 'arksnorman', '/home/arksnorman/git/sis/src/core/App/../../../downloads/timetables/5a2fdaa89504b-arksnorman.pem', '/downloads/timetables/5a2fdaa89504b-arksnorman.pem', '2017-12-12 04:33:28pm');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `admin` int(1) NOT NULL,
  `date-joined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstname`, `lastname`, `password`, `admin`, `date-joined`) VALUES
(1, 'arksnorman', 'kidhoma', 'norman', '$2y$10$5MqVZBytWldYeP1VBmaW6.e4LwF6Lt.4JH9rdTd5tsOxpBaBNaw0G', 1, '2017-06-22 20:30:50'),
(2, 'kidhoma', 'arks', 'norman', '$2y$10$5MqVZBytWldYeP1VBmaW6.e4LwF6Lt.4JH9rdTd5tsOxpBaBNaw0G', 0, '2017-06-24 18:25:47'),
(3, 'vishu', 'vishu', 'singh', '1234', 1, '2017-09-16 15:19:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lecturers`
--
ALTER TABLE `lecturers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetables`
--
ALTER TABLE `timetables`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `lecturers`
--
ALTER TABLE `lecturers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `timetables`
--
ALTER TABLE `timetables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
